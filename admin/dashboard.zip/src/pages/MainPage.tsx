import PageLayout from "../layouts/PageLayout"

const MainPage = () => {
  return (
    <PageLayout>
    <div className="p-0 sm:ml-64">
        <div className="flex items-center justify-center h-48 mb-4 rounded bg-gray-50 dark:bg-gray-800">
            <p className="text-2xl font-bold text-gray-800 dark:text-gray-50">
                Main DashBoard
            </p>
        </div>
    </div>
</PageLayout>);
}

export default MainPage