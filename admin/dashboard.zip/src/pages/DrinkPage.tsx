import PageLayout from "../layouts/PageLayout";
import Table from "../components/Table";
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import axios from 'axios';
import {useForm} from 'react-hook-form';

const DrinkPage = () => {

    const header = {
        attributes: ["Drink name", "Price", "Category", "Image"],
        path: "drinks"
    };
    const { register, handleSubmit, reset } = useForm(); 
    const client = useQueryClient();

    const { data, isLoading, isError, error } = useQuery({
        queryKey: ['drinks'],
        queryFn: async () => {
            try {
                const { data } = await axios.get('http://localhost:8080/api/drinks');
                return data;
            } catch (error) {
                console.error(error);
            }
        }
    });

    const { data: cateData, isLoading: cateIsLoading} = useQuery({
        queryKey: ['categories'],
        queryFn: async () => {
            try {
                const { data } = await axios.get('http://localhost:8080/api/categories');
                return data;
            } catch (error) {
                console.error(error);
            }
        }
    });

    const mutation = useMutation({
        mutationKey: 'drinks',
        mutationFn: async (formData) => {
            try {
                const { data } = await axios.post('http://localhost:8080/api/drinks', formData);
                return data;
            } catch (error) {
                console.error(error);
            }
        },
        onSuccess: () => {
            client.invalidateQueries('drinks');
        }
    });

    const onSubmit = async (formData) => {
        try {
            await mutation.mutateAsync(formData); 
 
            client.invalidateQueries('drinks'); 
        } catch (error) {
            console.error(error);
        }
    };

    
    const onDelete = useMutation({
        mutationKey: 'drinks',
        mutationFn: async (drinkId) => {
            try {
                await axios.delete(`http://localhost:8080/api/drinks/${drinkId}`);
            } catch (error) {
                console.error(error);
            }
        },
        onSuccess: () => {
            client.invalidateQueries('drinks');
        }
    });


    console.log(data);
    return (
        <PageLayout>
            <div className="p-0 sm:ml-64  h-auto dark:bg-gray-800">
                <div className="flex items-center justify-center h-48 mb-4 rounded bg-gray-50 dark:bg-gray-800">
                    <p className="text-2xl font-bold text-gray-800 dark:text-gray-50">
                        Drink Page DashBoard
                    </p>
                </div>
                <form className="max-w-sm mx-auto mb-4" onSubmit={handleSubmit(onSubmit)}>
                    <div className="mb-5">
                        <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Drink name</label>
                        <input {...register('name')} type="text" id="name" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="New drink name" required />
                    </div>
                    <div className="mb-5">
                        <label htmlFor="price" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Drink price</label>
                        <input {...register('price')} type="number" id="price" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="New drink" required />
                    </div>
                    <div className="mb-5">
                        <label htmlFor="category" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Category name</label>
                        <select {...register('category')} name="category" id="cate" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                            <option value={""}>Choose a category</option>
                            {cateData?.map(e => (
                                <option key={e?._id} value={e?.name}>{e?.name}</option>
                            ))}
 
                        </select>
                    </div>
                    <div className="mb-5">
                        <label htmlFor="image" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Image</label>
                        <input {...register('image')} name="image" type="text" id="image" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="New drink image" required />
                    </div>
                    <button type="submit" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Add</button>
                </form>
                {isLoading ? <h1>Loading data table...</h1> : (<Table header={header} data={data} onDelete={onDelete}/>)}

            </div>
        </PageLayout>

    )
}

export default DrinkPage