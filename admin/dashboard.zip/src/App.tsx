import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import NotFound from './pages/NotFound';
import MainPage from './pages/MainPage';
import LoginPage from './pages/LoginPage';
import DrinkPage from './pages/DrinkPage';
import Register from './pages/Register';
import DrinkCategoriesPage from './pages/DrinkCategoriesPage';
import { QueryClientProvider , QueryClient } from '@tanstack/react-query';
import EditCategoryPage from './pages/EditCategoryPage';
import EditDrinkPage from './pages/EditDrinkPage';

const queryClient = new QueryClient();
function App() {
  const isLoggedIn = !!localStorage.getItem('token'); 

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          
          <Route path='/' element={isLoggedIn ? <MainPage /> : <Navigate to="/login" />} />
          <Route path='/login' element={!isLoggedIn ? <LoginPage /> : <Navigate to="/" />} />
          <Route path='/register' element={!isLoggedIn ? <Register /> : <Navigate to="/" />} />

        {isLoggedIn && (
            <>
              <Route path='/drinks' element={<DrinkPage />} />
              <Route path='/categories' element={<DrinkCategoriesPage />} />
              <Route path='/categories/edit/:id' element={<EditCategoryPage />} />
              <Route path='/drinks/edit/:id' element={<EditDrinkPage />} />
            </>
          )}


          <Route path='*' element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}

export default App
